""" another_mod_inside_lec.py

Another module inside the `lectures` package
"""

from lectures import mod_inside_lec